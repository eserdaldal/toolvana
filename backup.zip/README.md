<!-- Auto-generated placeholder -->
📁 All documentation has been moved to the `docs/` folder.

🔗 [English README](docs/readme_en.md)  
🔗 [Turkish README](docs/readme_tr.md)